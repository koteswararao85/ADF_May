
# magnus-datafactory

## Azure Data Factory.

Guidelines: 
  
Each data intake should have it's own pipeline. 

Make each function as generic as possible. (Reduces the foot print. Hence improves the maintainability)

Make each re-usable component as a separate pipeline with parameters

Have the environment specific values to the global variables.


## GIT Configuration

On initial access to the Azure Data Factory you will be prompted to login into github. Use your optum email id (ending with optum.com). 
Select Working Branch as : Use Existing  and select the branch appropriate branch



## Steps to update for each environment.

### Update global variables accordings (Please check dev enviroment for the sample values)

#### DBX Related

dbx_workspace_id

dbx_user_id        : User with which we run the dbt jobs. (need to use service principle)

dbx_bronze_job_id

dbx_silver_job_id

dbx_gold_job_id

#### Tracking App Related

tracking_host

tracking_path

tracking_scope

tracking_client_id

tracking_token_path

tracking_kv_secret : Path to the Key Store URL 


### Linked Services 

Storage Linked Service - update service principle and storage account

Key Valut Linked Service - Update Key Vault

### Private End Points (PEP) for storage accounts

Update the git (PEP) in the git to match with the actual values. This can be taken from live mode JSON.

### The Pipelines uses the following secrets from the KEY STORE

CLIENT_SECRET : secret for the service principle to access the storage

TRACKING_KV_SECRET; secreat for getting the token for tracking

DBX_ACCESS_TOKEN: Access token for Databricks Jobs
